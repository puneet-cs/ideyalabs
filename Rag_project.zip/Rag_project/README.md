# Langchain : Framework
# Vector database : ChromaDB
# Huggingface
# LLM : GROQ : llama
# Get the API key to access the LLM

# Project Name: RAG based Website research assistant

# 1. Mention all the require library & install
# pip install -r requirements.txt

# 2. Create API key to access LLM using GROQ platfrom

# streamlit run main.py