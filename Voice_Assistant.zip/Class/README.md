🎙️ Voice Assistant with Groq + Streamlit
A personal voice assistant web app built with Streamlit, powered by Groq's LLaMA 3.3-70B model. The assistant listens to your voice, interacts with AI, and responds like Brahmanandam, a South Indian cinema legend — with short, humorous replies!

🚀 Features
🎤 Voice input using microphone

🤖 AI responses powered by Groq Cloud (LLaMA 3.3-70B)

🗣️ Text-to-Speech (TTS) with selectable girl or boy voice

💬 Text chat input alternative

🔁 Persistent chat history during session

🔊 Speech synthesis of AI responses

🧹 Clear chat option

🎭 Responds in a fun South Indian/Brahmanandam-style tone

🛠️ Tech Stack
Technology	Description
Streamlit	Web interface
Groq API	LLM backend (LLaMA 3.3-70B)
SpeechRecognition	Converts voice to text
pyttsx3	Text-to-speech synthesis
Python-dotenv	Environment variable management

📦 Installation
Clone the Repository

bash
Copy
Edit
git clone https://github.com/your-username/voice-assistant.git
cd voice-assistant
Create and activate a virtual environment (recommended)

bash
Copy
Edit
python -m venv venv
source venv/bin/activate    # On Windows: venv\Scripts\activate
Install the dependencies

bash
Copy
Edit
pip install -r requirements.txt
Set up environment variables

Create a .env file in the root directory:

ini
Copy
Edit
GROQ_API_KEY=your_groq_api_key_here
▶️ How to Run
Start the app using Streamlit:

bash
Copy
Edit
streamlit run app.py
Then, open your browser to http://localhost:8501

📸 App Preview


💡 Example Usage
Click "Start voice input" to ask a question via mic.

Or type into "Text input".

Hear Brahmanandam-style one-liner AI replies.

Choose voice gender from the sidebar.

Clear chat anytime to restart.

📁 Project Structure
bash
Copy
Edit
voice-assistant/
│
├── app.py              # Main Streamlit app
├── .env                # Environment file (not committed)
├── requirements.txt    # Required Python packages
└── README.md           # Project documentation
⚠️ Troubleshooting
Mic not working: Make sure microphone permissions are granted to your browser.

TTS errors: Some systems may lack default voices; test pyttsx3 locally.

Groq errors: Ensure your GROQ_API_KEY is correct and active.

👨‍💻 Author
Puneet Kansal
Feel free to connect or contribute!

📜 License
This project is licensed under the MIT License.

