# University Management System

# Define a base class 'person'
class person:
    # Constructor for initializing roll number and name
    def __init__(self, branch, name):
        self.branch = branch  # Assign roll number to the object
        self.name = name      # Assign name to the object

# Define 'student' class inheriting from 'person'
class student(person):
    # Constructor for initializing rollno, name, and branch
    def __init__(self, rollno, name, branch):
        super().__init__(branch, name)  # Call parent class constructor
        self.rollno = rollno            # Assign branch to student

# Define 'teacher' class inheriting from 'person'
class teacher(person):
    # Constructor for initializing rollno, name, and subject
    def __init__(self, branch, name, subject):
        super().__init__(branch, name)  # Call parent class constructor
        self.subject = subject          # Assign subject to teacher

# Define 'college' class to manage students and teachers
class college:
    # Constructor for initializing college name, and lists to hold students and teachers
    def __init__(self, cname):
        self.cname = cname
        self.students = []  # List to store student objects
        self.teachers = []  # List to store teacher objects

    # Method to add a student to the college
    def add_student(self, student):
        self.students.append(student)

    # Method to add a teacher to the college
    def add_teacher(self, teacher):
        self.teachers.append(teacher)

   
# Create an empty list to store college objects
colleges = []

# Infinite loop for user interaction
while True:
    # Menu display
    print("Choose the Required option: ")
    print("1. Create College.")
    print("2. Add Student.")
    print("3. Add Teacher.")
    print("4. Display Students.")
    print("5. Display Teachers.")
    print("6. Display Colleges")
    print("7. Exit.")

    # Get user input for option
    x = int(input("Enter your Option: "))

    # Option 1: Create a college
    if x == 1:
        clgname = input("Enter College Name: ")
        temp = False
        # Check if college already exists
        for x in colleges:
            if clgname == x.cname:
                temp = True
                break
        if temp == True:
            print()
            print("College Already Exists !")
            print()
        else:
            clg = college(clgname)   # Create new college
            colleges.append(clg)     # Add to list
            print()
            print("College Added Sucessfully")
            print()

    # Option 2: Add a student
    elif x == 2:
        clgname = input("Enter College Name: ")
        temp = False
        for x in colleges:
            if clgname == x.cname:
                clg = x  # Get the matching college object
                temp = True
                break
        if temp == True:
            rollno = input("Enter Roll no: ")
            name = input("Enter Student Name: ")
            branch = input("Enter Student Branch: ")
            s1 = student(rollno, name, branch)  # Create student object
            clg.add_student(s1)             # Add student to college
            #  Note: Python does not have block-level scope like C/C++/Java. It only has function-level scope. So, We can access "clg" here
            print()
            print("Student Added Sucessfully ")
            print()
        else:
            print()
            print("College Does not Exists !")
            print()

    # Option 3: Add a teacher
    elif x == 3:
        clgname = input("Enter COllege Name: ")
        temp = False
        for x in colleges:
            if clgname == x.cname:
                clg = x  # Get the matching college object
                temp = True
                break
        if temp == True:
            branch = input("Enter Branch: ")
            name = input("Enter Teacher Name: ")
            subject = input("Enter Subject: ")
            t1 = teacher(branch, name, subject)  # Create teacher object
            clg.add_teacher(t1)                  # Add teacher to college
            print()
            print("Teacher Added Sucessfully !")
            print()
        else:
            print()
            print("College Does not Exists !")
            print()

    # Option 4: Display all students of a college
    elif x == 4:
        clgname = input("Enter College Name: ")
        temp = False
        for x in colleges:
            if clgname == x.cname:
                clg = x  # Get the matching college object
                temp = True
                break
        if temp == True:
            details = clg.students
            n = len(details)
            print()
            for i in range(n):
                print(f"Student {i+1}:")
                print(f"Roll Number: {details[i].rollno}")
                print(f"Name : {details[i].name}")
                print(f"Branch: {details[i].branch}")
                print()
        else:
            print()
            print("College Does not Exists !")
            print()

    # Option 5: Display all teachers of a college
    elif x == 5:
        clgname = input("Enter College Name: ")
        temp = False
        for x in colleges:
            if clgname == x.cname:
                clg = x  # Get the matching college object
                temp = True
                break
        if temp == True:
            details = clg.teachers
            n = len(details)
            print()
            for i in range(n):
                print(f"Teacher {i+1}:")
                print(f"Branch Number: {details[i].branch}")
                print(f"Name : {details[i].name}")
                print(f"Subject: {details[i].subject}")
                print()
        else:
            print()
            print("College Does not Exists !")
    
    
    elif x == 6:  # <<< Display College Names
        if len(colleges) == 0:
            print("\nNo Colleges Added Yet!\n")
        else:
            print("\nList of Colleges:")
            for i, c in enumerate(colleges):
                print(f"{i+1}. {c.cname}")
            print()

    # Option 6: Exit the loop
    elif x == 7:
        break

    # Invalid option handling6
    else:
        print()
        print("choose the COrrect Option")
        print()
