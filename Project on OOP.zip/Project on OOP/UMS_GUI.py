"""
app.py
-------
A Streamlit‑based APP on University Management System (UMS).

Run with:
    streamlit run app.py

Main features
-------------
* Create colleges
* Add students and teachers to a college
* Display records
* Persist data in Streamlit’s session_state (so everything survives page reruns)

Author: <Puneet Kansal>
Date  : 30‑Jun‑2025
"""

# ============================= 1. Standard Library Imports ============================= #
import streamlit as st      # Streamlit supplies all the widgets and web‑app framework


# ---------- 2.1 Base class ------------------------------------------------------------- #
class person:
    """A common parent for Student and Teacher so we don’t repeat `branch` + `name`."""
    
    def __init__(self, branch: str, name: str) -> None:
        self.branch = branch           # e.g. “CSE”, “ECE”; kept generic so teachers share it
        self.name   = name             # Full name of the person


    def __str__(self) -> str:   # Helps Streamlit display the object nicely
        return f"Name: {self.name} | Branch: {self.branch}"

# __str__	Special method name — automatically called by print() and str()
# -> str	Type hint: this method returns a string

# ---------- 2.2 Student class ---------------------------------------------------------- #
class student(person):     
    def __init__(self, rollno: str, name: str, branch: str) -> None:
        super().__init__(branch, name) # Re‑use base constructor
        self.rollno = rollno           # Unique student identifier

    def __str__(self) -> str:
        return f"Roll No: {self.rollno} | {super().__str__()}"


# ---------- 2.3 Teacher class ---------------------------------------------------------- #
class teacher(person):
    
    def __init__(self, branch: str, name: str, subject: str) -> None:
        super().__init__(branch, name) # Populate `branch` and `name`
        self.subject = subject         # Primary teaching subject

    def __str__(self) -> str:
        return f"{super().__str__()} | Subject: {self.subject}"


# ---------- 2.4 College class ---------------------------------------------------------- #
class college:
    
    def __init__(self, cname: str) -> None:
        self.cname    = cname       # College name — the primary key in our tiny system
        self.students = []          # List[student]
        self.teachers = []          # List[teacher]

    # ---------- CRUD methods -------- #
    def add_student(self, s: student) -> None:
        """Append a `student` "object" to the college roster."""
        self.students.append(s)

    def add_teacher(self, t: teacher) -> None:
        """Append a `teacher` object to the staff list."""
        self.teachers.append(t)


# ============================= 3. Streamlit Helper ==================================== #
 """
    Utility function to locate a college object inside `st.session_state.colleges`.
    Returns `None` if not present.
"""
def find_college(cname: str):
   
    return next((c for c in st.session_state.colleges if c.cname == cname), None)

# next() retrieves the first matching college "Object" from list(iterator) of colleges, If no match exists, it returns None

# ============================= 4. Streamlit Page Layout =============================== #
# -- 4.1 Configure the web‑page meta‑data (appears in browser tab) --
st.set_page_config(page_title="University Management System",
                   layout="wide")  # compact central column

# -- 4.2 Title banner : Icon: write in google Univerity emoji--
st.title("🏛️University Management System")

# -- 4.3 Initialize session storage on first run --
if "colleges" not in st.session_state:          # Persist across reruns
    st.session_state.colleges = []              # type: list[college]

# -- 4.4 Sidebar menu (acts as navigation) --
menu_choice = st.sidebar.radio(
    "Select Action",
    (
        "Create College",
        "Add Student",
        "Add Teacher",
        "Display Students",
        "Display Teachers",
        "List Colleges"
    )
)

# ============================= 5. Menu Handlers ======================================= #

# ---------- 5.1 Create a new college -------------------------------------------------- #
if menu_choice == "Create College":
    cname = st.text_input("Enter new college name")
    if st.button("Create"):
        if not cname:                                        # Validation guard
            st.error("College name cannot be empty.")
        elif find_college(cname):
            st.warning("❗ College already exists.")
        else:
            st.session_state.colleges.append(college(cname))  # create a college class object and store in list of session state colleges
            st.success(f"✅ '{cname}' created successfully!")

# ---------- 5.2 Add a student --------------------------------------------------------- #
elif menu_choice == "Add Student":
    if not st.session_state.colleges:
        st.info("Please create a college first ➡️")
    else:
        # --- Inputs grouped for clarity ---
        clgname = st.selectbox("Choose College",
                               [c.cname for c in st.session_state.colleges])
        roll    = st.text_input("Roll Number")
        sname   = st.text_input("Student Name")
        branch  = st.text_input("Branch (e.g. CSE)")

        if st.button("Add Student"):
            if not (roll and sname and branch):
                st.error("All fields are required.")
            else:
                clg = find_college(clgname)
                clg.add_student(student(roll, sname, branch))
                st.success("🎉 Student added!")

# ---------- 5.3 Add a teacher --------------------------------------------------------- #
elif menu_choice == "Add Teacher":
    if not st.session_state.colleges:
        st.info("Please create a college first ➡️")
    else:
        clgname = st.selectbox("Choose College",
                               [c.cname for c in st.session_state.colleges])
        tname   = st.text_input("Teacher Name")
        branch  = st.text_input("Branch (e.g. CSE)")
        subj    = st.text_input("Subject (e.g. Algorithms)")

        if st.button("Add Teacher"):
            if not (tname and branch and subj):
                st.error("All fields are required.")
            else:
                find_college(clgname).add_teacher(teacher(branch, tname, subj))
                st.success("🎉 Teacher added!")

# ---------- 5.4 Display students ------------------------------------------------------ #
elif menu_choice == "Display Students":
    if not st.session_state.colleges:
        st.info("No colleges in system yet.")
    else:
        clgname = st.selectbox("Choose College",
                               [c.cname for c in st.session_state.colleges])
        st.subheader(f"Students in {clgname}")
        clg = find_college(clgname)
        if clg.students:
            for i, s in enumerate(clg.students, 1):
                st.write(f"**{i}.** {s}")            # ** will bold i value
        else:
            st.warning("No students found.")

# ---------- 5.5 Display teachers ------------------------------------------------------ #
elif menu_choice == "Display Teachers":
    if not st.session_state.colleges:
        st.info("No colleges in system yet.")
    else:
        clgname = st.selectbox("Choose College",
                               [c.cname for c in st.session_state.colleges])
        st.subheader(f"Teachers in {clgname}")
        clg = find_college(clgname)
        if clg.teachers:
            for i, t in enumerate(clg.teachers, 1):
                st.write(f"**{i}.** {t}")
        else:
            st.warning("No teachers found.")

# ---------- 5.6 List all colleges ----------------------------------------------------- #
elif menu_choice == "List Colleges":
    st.subheader("📋 All Colleges")
    if not st.session_state.colleges:
        st.warning("No colleges added yet.")
    else:
        for i, c in enumerate(st.session_state.colleges, 1):
            st.write(f"{i}. {c.cname}")

# ============================= End of File ============================================ #
